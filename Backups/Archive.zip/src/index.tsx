import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import * as serviceWorker from './serviceWorker';

import Keycloak from 'keycloak-js';
import { KeycloakProvider } from 'react-keycloak';

import CssBaseline from '@material-ui/core/CssBaseline';
import { ThemeProvider } from '@material-ui/styles';
import theme from "../src/theme/theme";
import { init } from './components/KeyCloak/module.keycloak.js';

import PersistApp from "./components/PersistApp";

// Initialize the Keycloak client
init();

// Setup Keycloak instance as needed
const keycloak =  Keycloak("./keycloak.json");

//ReactDOM.render(<KeycloakProvider keycloak={keycloak}><ThemeProvider theme={theme}><CssBaseline /><App /></ThemeProvider></KeycloakProvider>, document.getElementById('root'));

//ReactDOM.render(<ThemeProvider theme={theme}><CssBaseline /><App /></ThemeProvider>, document.getElementById('root'));

ReactDOM.render(<PersistApp />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();