import React from 'react';
import Keycloak, { keycloak } from './components/KeyCloak/Keycloak';

const Secured2 = props => {
    console.log(keycloak.idTokenParsed);
    return(
        <Keycloak>
            <div>Welcome!  This is the Secured Page 2.</div>
        </Keycloak>
    );
		
}

export default Secured2;