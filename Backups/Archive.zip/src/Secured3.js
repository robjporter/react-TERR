import React from 'react';
import { useKeycloak } from 'react-keycloak';


function Secured3() {
    const { keycloak, initialized } = useKeycloak();

    if(keycloak.idTokenParsed) {
        console.log("TOKEN EXPIRED: ",keycloak.isTokenExpired());
        console.log("TOKEN: ",keycloak.idTokenParsed);
    }
    
    return(
        <div>
            <div>{`User is ${!keycloak.authenticated ? 'NOT ' : ''}authenticated`}</div>

            {!!keycloak.authenticated && (
            <button type="button" onClick={() => keycloak.logout()}>
                Logout
            </button>
            )}

            {!keycloak.authenticated && (
            <button type="button" onClick={() => keycloak.login()}>
                Login
            </button>
            )}
        </div>
    );
}

export default Secured3;