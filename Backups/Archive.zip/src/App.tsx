import React from 'react';
import { BrowserRouter, Route, Link } from 'react-router-dom';
import Welcome from './Welcome';
import Secured from './Secured';
import Secured2 from './Secured2';
import Secured3 from './Secured3';
import Secured4 from './Secured4';

import Button from '@material-ui/core/Button';

const App: React.FC = () => {
  return (
    
    <BrowserRouter>
    <div className="container">
      
          <Link to="/" style={{textDecoration:"none"}}><Button variant="contained" color="primary">public component</Button></Link>
          <Link to="/secured" style={{textDecoration:"none"}}><Button variant="contained" color="primary">secured component</Button></Link>
          <Link to="/secured2" style={{textDecoration:"none"}}><Button variant="contained" color="primary">secured2 component</Button></Link>
          <Link to="/secured3" style={{textDecoration:"none"}}><Button variant="contained" color="primary">secured3 component</Button></Link>
          <Link to="/secured4" style={{textDecoration:"none"}}><Button variant="contained" color="primary">secured4 component</Button></Link>

      <Route exact path="/" component={Welcome} />
      <Route path="/secured" component={Secured} />
      <Route path="/secured2" component={Secured2} />
      <Route path="/secured3" component={Secured3} />
      <Route path="/secured4" component={Secured4} />
    </div>
  </BrowserRouter>
  );
}

export default App;